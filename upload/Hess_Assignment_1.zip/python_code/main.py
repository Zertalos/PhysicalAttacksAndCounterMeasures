###
#
# Assignment 1 solution for PAC
# Christian Werner Heß - Matrikelnummer 1996650
#
##
from src import Assignment1

if __name__ == "__main__":
    Assignment1

