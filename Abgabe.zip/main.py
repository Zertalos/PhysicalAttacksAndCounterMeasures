###
#
# Assignment_1 solution for PAC
# Christian Werner Heß - 1996650
#
##
from src import Assignment1

if __name__ == "__main__":
    Assignment1

