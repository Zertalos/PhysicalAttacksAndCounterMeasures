import os
import zipfile
import subprocess
import platform
import sys

import os
import zipfile

def create_requirements_file():
    result = subprocess.run([sys.executable, '-m', 'pip', 'freeze'], capture_output=True, text=True)
    if result.returncode == 0:
        with open('requirements.txt', 'w') as f:
            f.write(result.stdout)
    else:
        print('Failed to create requirements.txt:', result.stderr, file=sys.stderr)
        sys.exit(result.returncode)




def add_to_zip(zipf, item, base_folder=""):
    if os.path.isdir(item):
        for root, dirs, files in os.walk(item):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, base_folder) if base_folder else None
                zipf.write(file_path, arcname)
    elif os.path.isfile(item):
        arcname = os.path.relpath(item, base_folder) if base_folder else None
        zipf.write(item, arcname)


def zip_files(output_filename: str, assignment_name: str, *args: str) -> None:
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Add files and directories
        for item in args:
            if os.path.isdir(item):
                for root, dirs, files in os.walk(item):
                    if '__pycache__' in root:
                        continue
                    for file in files:
                        if '__pycache__' in file:
                            continue
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, os.path.dirname(item))
                        zipf.write(file_path, arcname)
            elif os.path.isfile(item) and '__pycache__' not in item:
                zipf.write(item)

        # Add requirements.txt
        zipf.write('requirements.txt')


        # Add empty folders
        for folder in ["input", "output"]:
            folder_path = f"{folder}/{assignment_name}/"
            zip_info = zipfile.ZipInfo(folder_path)
            zipf.writestr(zip_info, '')


def open_folder_in_explorer(folder_path: str) -> None:
    system = platform.system()
    if system == "Windows":
        os.startfile(folder_path)
    elif system == "Darwin":  # macOS
        subprocess.run(["open", folder_path])
    else:  # Linux
        subprocess.run(["xdg-open", folder_path])


if __name__ == "__main__":
    assignment_name = "Assignment_1"
    output_zip = "Abgabe.zip"

    # Create requirements.txt
    create_requirements_file()

    # Create zip file
    zip_files(
        output_zip,
        assignment_name,
        'main.py',
        'src'
    )

    # Open the directory in Explorer
    output_folder = os.path.dirname(os.path.abspath(__file__))
    open_folder_in_explorer(output_folder)